﻿编译 chm 文件说明   
1.安装 HTML Help Workshop(hhc.exe)    
2.compile_chm.ahk 文件中修改 hhc 变量为 hhc.exe 程序的路径   
3.使用 U版主程序运行 compile_chm.ahk   
4.重建搜索列表 需用 2.0 的 U版主程序运行 build_search.ahk.   